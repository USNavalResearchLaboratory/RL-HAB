import numpy as np
import matplotlib.pyplot as plt
import random
import math
from matplotlib.animation import FuncAnimation

class FlowFieldEnv:
    def __init__(self):
        self.WIDTH = 100
        self.HEIGHT = 100
        self.NUM_FLOW_LEVELS = 5
        self.dt = 0.1
        self.flow_field = np.zeros((self.NUM_FLOW_LEVELS, self.WIDTH))
        for altitude in range(self.NUM_FLOW_LEVELS):
            wind_direction = np.random.choice([-1, 1])
            wind_speed = np.random.uniform(0.5, 10)
            self.flow_field[altitude, :] = wind_direction * wind_speed

    def horizontal_flow(self, position):
        altitude_level = int((position[1] / self.HEIGHT) * self.NUM_FLOW_LEVELS)
        return self.flow_field[altitude_level, 0]

    def is_point_valid(self, point):
        return point[0] >= -100 and point[0] <= 100 and point[1] >= 0 and point[1] <= self.HEIGHT

class RRT:
    def __init__(self, env, start, goal, max_iter=1000, max_distance=5):
        self.env = env
        self.start = start
        self.goal = goal
        self.max_iter = max_iter
        self.max_distance = max_distance
        self.nodes = [start]

    def plan(self):
        for i in range(self.max_iter):
            print(i)
            rand_point = np.array([random.uniform(-100, 100), random.uniform(0, self.env.HEIGHT)])
            nearest_node_idx = self._find_nearest_node(rand_point)
            nearest_node = self.nodes[nearest_node_idx]
            new_node = self._extend(nearest_node, rand_point)
            if np.linalg.norm(new_node - self.goal) < self.max_distance:
                return self._construct_path(nearest_node_idx, len(self.nodes) - 1)
        return None

    def _find_nearest_node(self, point):
        distances = [np.linalg.norm(node - point) for node in self.nodes]
        return np.argmin(distances)

    def _extend(self, from_node, to_point):
        direction = to_point - from_node
        distance = min(np.linalg.norm(direction), self.max_distance)
        horizontal_flow = self.env.horizontal_flow(from_node)
        vertical_distance = min(abs(to_point[1] - from_node[1]), 2) * np.sign(to_point[1] - from_node[1])
        new_node = np.array([from_node[0] + horizontal_flow * self.env.dt, from_node[1] + vertical_distance])
        if self._is_valid_edge(from_node, new_node):
            self.nodes.append(new_node)
            return new_node
        return from_node

    def _is_valid_edge(self, from_node, to_node):
        step_size = 0.1
        num_steps = int(np.linalg.norm(to_node - from_node) / step_size)
        for i in range(num_steps):
            point = from_node + (to_node - from_node) * (i / num_steps)
            if not self.env.is_point_valid(point):
                return False
        return True

    def _construct_path(self, start_idx, end_idx):
        path = [self.goal]
        current_idx = end_idx
        while current_idx != start_idx:
            path.append(self.nodes[current_idx])
            current_idx = self._find_parent(current_idx)
        path.append(self.start)
        return path[::-1]

    def _find_parent(self, node_idx):
        current_node = self.nodes[node_idx]
        min_distance = float('inf')
        parent_idx = -1
        for i in range(node_idx - 1, -1, -1):
            if np.linalg.norm(current_node - self.nodes[i]) < min_distance:
                min_distance = np.linalg.norm(current_node - self.nodes[i])
                parent_idx = i
        return parent_idx

def visualize(env, rrt, path=None):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.imshow(env.flow_field, cmap='coolwarm', aspect='auto', extent=[-100, 100, 0, env.HEIGHT])
    ax.plot(rrt.start[0], rrt.start[1], 'go', label='Start')
    ax.plot(rrt.goal[0], rrt.goal[1], 'bo', label='Goal')
    ax.legend()
    ax.set_xlabel('X')
    ax.set_ylabel('Altitude')
    ax.set_title('RRT Path Planning in Flow Field Environment')
    ax.invert_yaxis()

    def update(frame):
        if frame < len(rrt.nodes):
            ax.plot(rrt.nodes[frame][0], rrt.nodes[frame][1], 'ko', markersize=1)
            if frame > 0:
                ax.plot([rrt.nodes[frame][0], rrt.nodes[rrt._find_parent(frame)][0]],
                        [rrt.nodes[frame][1], rrt.nodes[rrt._find_parent(frame)][1]], 'k-', linewidth=0.5)
        else:
            if path:
                ax.plot([point[0] for point in path], [point[1] for point in path], 'ro-')
            else:
                ax.text(0.5, 0.5, "No path found", horizontalalignment='center',
                        verticalalignment='center', transform=ax.transAxes, fontsize=12, color='red')
            ani.event_source.stop()

    ani = FuncAnimation(fig, update, frames=len(rrt.nodes) + 1, interval=1)
    plt.show()


if __name__ == "__main__":
    env = FlowFieldEnv()
    start = np.array([random.uniform(-80, 80), random.uniform(20, 80)])
    goal = np.array([random.uniform(-80, 80), random.uniform(20, 80)])
    rrt = RRT(env, start, goal)
    path = rrt.plan()

    if path is None:
        print("No path found")
    else:
        print("Path found:", path)
        visualize(env, rrt, path)
